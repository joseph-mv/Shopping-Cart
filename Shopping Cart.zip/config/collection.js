module.exports={
    Product_Collection:'Products',
    User_Collection:'Users',
    Cart_Collection:'Cart',
    Orders_Collection:'Orders',
    Admin_Collection:'Admin',
}


